package gui;

import java.awt.Dialog;
import java.awt.FlowLayout;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.text.ParseException;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dialog;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.text.ParseException;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import Model.Auto;
import gui.AutoFrame.NorthPanel.FirstLine;


import Model.Auto;

public class AutoDialog extends JDialog implements ActionListener{

	public boolean closedOK = false;	// true, wenn Dialog durch OK beendet wird

	// Referenz auf das Model-Objekt als Datenquelle:
	private Auto myAuto;

	// Dialogelemente als Instanzvariablen:
	private JTextField 		Autokennzeichen       =  new  JTextField(10);	// 10 Spalten
	private JLabel			lblAutokennzeichen    =  new JLabel("Autokennzeichen                                      ");

	private JTextField 		Datum      =   new JTextField(10);
	private JLabel			lblDatum   =   new JLabel("Datum                                                           ");
  
	//Aufz�hlung mehrerer Autostile
	private String wahl;
	private String[] texte ={"Bitte auswaehlen Sie","regnet","sonnig","bew�lkt","Schnee","Nebel","windig"};

	//ComboBox hinzuf�gen 
	private JComboBox<String>  Wetter     = new JComboBox<String>(texte);
	private JLabel			   lblWetter  = new JLabel("Wetter                                               ");
	
	//Checkbox hinzuf�gen
	private JCheckBox		   Verst��e = new JCheckBox("Verst��e ");
	
	private String wahl1;
	private String[] texte1 ={"Bitte auswaehlen Sie","...","eine Rote Ampel �berfahren","�bergeschwindigkeit","besoffen fahren","falsch parken","gegen Orientierung fahren",
			                  "�bergewicht","Ohne Fahrschein"};
	
	private JComboBox<String>		Stil     = new JComboBox<String>(texte1);
	private JLabel			        lblStil  = new JLabel("Stil                                         ");
	

	
	private JTextField      MAXfahrgeschwindigkeit  = new JTextField(10);
	private JLabel          lblMAXfahrgeschwindigkeit  = new JLabel("MAXfahrgeschwindigkeit           ");
	private JLabel          lblEinheit  = new JLabel("km/h ");
	
	private JTextField      Strafgeld  = new JTextField(10);
	private JLabel          lblStrafgeld  = new JLabel("Strafgeld                                         ");
	private JLabel          lblEinheit1  = new JLabel("Euro ");
	
	
	private JTextField 		Breitengrad      =   new JTextField(10);
	private JLabel			lblBreitengrad   =   new JLabel("Breitengrad                                    ");
	private JLabel          lblEinheit2  = new JLabel(" grad");
	
	
	private JTextField 		L�ngengrad     =   new JTextField(10);
	private JLabel			lblL�ngengrad  =   new JLabel("L�ngengrad                                   ");
	private JLabel          lblEinheit3  = new JLabel(" grad");
	
	//Button "Ok" und "Abbrechen
	private JButton			ok		  = new JButton("OK");
	private JButton			abbrechen = new JButton("Abbrechen");
	
	
	
	
	


	/**
	 * Konstruktor initialisiert den Dialog.
	 * Das Dialogfenster hat keine Daten, wenn ein neues Auto angelegt wird. In diesem
	 * Fall ist das �bergebenen Auto-Objekt leer.
	 * Wird ein vorhandener Auto bearbeitet, werden dessen Daten zu Initialisierung
	 * der GUI-Elemente verwendet.
	 */
	public AutoDialog (Window parent, Auto m) {

		super (parent, "Daten bearbeiten", Dialog.ModalityType.APPLICATION_MODAL ); // Modaler Dialog, Titel wird sp�ter gesetzt
		myAuto = m;

		// Daten aus Autosobjekt �bernehmen:
		Autokennzeichen.setText(m.getAutokennzeichen());
		Datum.setText(m.getDatum());  
		Wetter.setSelectedItem(""+m.getWetter());
		Verst��e.setSelected(m.getVerst��e());
		Stil.setSelectedItem(""+m.getStil());

		
		// MAXfahrgeschwindigkeit   (double-Wert f�r Note in formatierten String mit 2 Dezimalstellen:)
				DecimalFormatSymbols dfs = DecimalFormatSymbols.getInstance();
				dfs.setDecimalSeparator(',');	// Dezimalkomma statt Punkt
				DecimalFormat df = new DecimalFormat ("0.00", dfs);  // 2 Dezimalstellen
				MAXfahrgeschwindigkeit.setText(df.format(m.getMAXfahrgeschwindigkeit()));
				
		//Strafgeld
				DecimalFormatSymbols dfs1 = DecimalFormatSymbols.getInstance();
				dfs1.setDecimalSeparator(',');	// Dezimalkomma statt Punkt
				DecimalFormat df1 = new DecimalFormat ("0.00", dfs1);  // 2 Dezimalstellen
				Strafgeld.setText(df1.format(m.getStrafgeld()));
				
	    //Breitengrad
				DecimalFormatSymbols dfs2 = DecimalFormatSymbols.getInstance();
				dfs2.setDecimalSeparator(',');	// Dezimalkomma statt Punkt
				DecimalFormat df2 = new DecimalFormat ("0.00", dfs2);  // 2 Dezimalstellen
				Breitengrad.setText(df2.format(m.getBreitengrad()));
				
		// L�ngergrad
				DecimalFormatSymbols dfs3 = DecimalFormatSymbols.getInstance();
				dfs3.setDecimalSeparator(',');	// Dezimalkomma statt Punkt
				DecimalFormat df3 = new DecimalFormat ("0.00", dfs3);  // 2 Dezimalstellen
				L�ngengrad.setText(df3.format(m.getL�ngengrad()));
				
				
		// Layout festlegen und GUI-Elemente hinzuf�gen:
		setLayout (new FlowLayout());	
 
		add (lblAutokennzeichen);		
		add (Autokennzeichen);
		add (lblDatum);		
		add (Datum);
		add (lblWetter);
		add (Wetter);
		add (lblStil);
		add (Stil);
		add (Verst��e);
		add (lblMAXfahrgeschwindigkeit);
		add (MAXfahrgeschwindigkeit);
		add (lblStrafgeld);
		add (Strafgeld);
		add (lblBreitengrad);
		add (Breitengrad);
		add (lblL�ngengrad);
		add (L�ngengrad);
		
		add (ok);
		add (abbrechen);
		pack();
		
		 

		// Layout festlegen und GUI-Elemente hinzufugen
		class WestPanel extends Box {
			/**
			 * Layout in FirstLine entwerfen.
			 */
			class FirstLine extends JPanel {
				public FirstLine() {
					setLayout (new FlowLayout(FlowLayout.LEFT));
					add (lblAutokennzeichen);
					setLayout (new FlowLayout(FlowLayout.RIGHT));
					add (Autokennzeichen );
				}
			}
			class SecondLine extends JPanel {
				/**
				 * Layout in SecondLine entwerfen.
				 */
				public SecondLine() {
					setLayout (new FlowLayout(FlowLayout.LEFT));
					add (lblDatum);
					setLayout (new FlowLayout(FlowLayout.RIGHT));
					add (Datum);
				}
			}
			class ThirdLine extends JPanel {
				/**
				 * Layout in ThirdLine entwerfen.
				 */
				public ThirdLine() {
					setLayout (new FlowLayout(FlowLayout.LEFT));
					add (lblWetter);
					setLayout (new FlowLayout(FlowLayout.RIGHT));
					add (Wetter);
				}
			}
			
			
			class FouthLine extends JPanel {
				/**
				 * Layout in FouthLine entwerfen.
				 */
				public FouthLine() {
					
					setLayout (new FlowLayout(FlowLayout.LEFT));
					add (Verst��e);
				}
			}
			
			
			
			class FifthLine extends JPanel {
				/**
				 * Layout in FouthLine entwerfen.
				 */
				public FifthLine() {
					setLayout (new FlowLayout(FlowLayout.LEFT));
					add (lblStil);
					setLayout (new FlowLayout(FlowLayout.RIGHT));
					add (Stil);
				}
			}
			
			
			
			
			class SixthLine extends JPanel {
				/**
				 * Layout in FouthLine entwerfen.
				 */
				public SixthLine() {
					setLayout (new FlowLayout(FlowLayout.LEFT));
					add (lblMAXfahrgeschwindigkeit);
					setLayout (new FlowLayout(FlowLayout.RIGHT));
					add (MAXfahrgeschwindigkeit);
					setLayout (new FlowLayout(FlowLayout.RIGHT));
					add (lblEinheit);
				}
			}
			
			class SeventhLine extends JPanel {
				/**
				 * Layout in FouthLine entwerfen.
				 */
				public SeventhLine() {
					setLayout (new FlowLayout(FlowLayout.LEFT));
					add (lblStrafgeld);
					setLayout (new FlowLayout(FlowLayout.RIGHT));
					add (Strafgeld);
					setLayout (new FlowLayout(FlowLayout.RIGHT));
					add (lblEinheit1);
					
					
				}
			}
			class EighthLine extends JPanel {
				/**
				 * Layout in FouthLine entwerfen.
				 */
				public EighthLine() {
					setLayout (new FlowLayout(FlowLayout.LEFT));
					add (lblBreitengrad);
					setLayout (new FlowLayout(FlowLayout.RIGHT));
					add (Breitengrad);
					setLayout (new FlowLayout(FlowLayout.RIGHT));
					add (lblEinheit2);
				}
			}
			class NinthLine extends JPanel {
				/**
				 * Layout in FouthLine entwerfen.
				 */
				public NinthLine() {
					setLayout (new FlowLayout(FlowLayout.LEFT));
					add (lblL�ngengrad );
					setLayout (new FlowLayout(FlowLayout.RIGHT));
					add (L�ngengrad );
					setLayout (new FlowLayout(FlowLayout.RIGHT));
					add (lblEinheit3);
				}
			}
			
			
			/**
			 * BoxLayout in WestPanel entwerfen.
			 */
			public WestPanel () {

				// 9 Zeilen sukzessiv aufkommen
				super (BoxLayout.Y_AXIS);
				add (new FirstLine());
				add (new SecondLine());
				add (new ThirdLine());
				add (new FouthLine());
				add (new FifthLine());
				add (new SixthLine());
				add (new SeventhLine());
				add (new EighthLine());
				add (new NinthLine());

			}
		}

		// Am SouthPanel gibt es zwei Button "OK" und "Abbrechen" und FlowLayout genutzt wird.
		class SouthPanel extends JPanel {
			/**
			 * Layout in SouthPanel entwerfen.
			 */
			public SouthPanel() {
				setLayout (new FlowLayout(FlowLayout.RIGHT));
				add (ok);
				add (abbrechen);
			}
		}


		

		setLayout (new BorderLayout());
		add (new WestPanel(), BorderLayout.WEST);
		add (new SouthPanel(), BorderLayout.SOUTH);

		// Event-Handler installieren:
		ok.addActionListener (this);
		abbrechen.addActionListener (this);
		this.setTitle ("Neue Auto hinzuf�gen");
		this.setLocation(300,50);   //Koordination: x=300, y=50;
		this.setSize (400, 500);	// Breite: 400 Pixel; Hoehe: 500 Pixel

		// Dialogfenster sichtbar machen:
		setVisible (true);	
	}


	/**
	 *  Klicken auf Button "Ok" (neue Autotitel hinzuf�gen) oder "Abbrechen" auswerten
	 */
	public void actionPerformed (ActionEvent e) {

		//  Schaltfl�che entnehmen:
		Object source = e.getSource();
		if (source == ok) {
			// Werte des Auto-Objekts entsprechend den Dialogelementen aktualisieren:

			myAuto.setAutokennzeichen (Autokennzeichen.getText());
			myAuto.setDatum(Datum.getText());
		    myAuto.setWetter((String) Wetter.getSelectedItem());
			myAuto.setStil((String) Stil.getSelectedItem());
			myAuto.setVerst��e(Verst��e.isSelected());
			
			
			//	Fahrgeschwindigkeit hat Dezimalkomma.	
			double Fahrgeschwindigkeit = 0;  // Voreinstellung(Fahrgeschwindigkeit =0.0), falls Textumwandlung schief geht
			
			//To format a number for a different locale. specify it in the call to getInstance.
		    //Formalieren Sie eine Nummer f�r eine andere Locale,geben Sie es in dem Aufruf von getInstance.
		    NumberFormat nf = NumberFormat.getInstance();
			try {
				Number sd = nf.parse(MAXfahrgeschwindigkeit.getText());
				Fahrgeschwindigkeit  = sd.doubleValue();		
			}
			catch (ParseException ex) {
			
		}
			myAuto.setMAXfahrgeschwindigkeit(Fahrgeschwindigkeit );
			
			
			//	Geld hat Dezimalkomma.	
			double Geld = 0;  // Voreinstellung(Spielauer =0.0), falls Textumwandlung schief geht

			NumberFormat nf1 = NumberFormat.getInstance();
			try {
				Number sd = nf1.parse(Strafgeld.getText());
				Geld  = sd.doubleValue();
		
			}
			catch (ParseException ex) {
			
	 }
			myAuto.setStrafgeld(Geld);
			
         
			//	Breiten hat Dezimalkomma.	
		  double Breiten = 0;  // Voreinstellung(Breiten =0.0), falls Textumwandlung schief geht
		
			NumberFormat nf2 = NumberFormat.getInstance();
			try {
				Number sd = nf2.parse(Breitengrad.getText());
				Breiten  = sd.doubleValue();
				
			}
			catch (ParseException ex) {
				
		}
			
			myAuto.setBreitengrad(Breiten);
			  
			
			//	Breiten hat Dezimalkomma.	
			double L�ngen = 0;  // Voreinstellung(L�ngen =0.0), falls Textumwandlung schief geht
		
		    NumberFormat nf3 = NumberFormat.getInstance();
			try {
				Number sd = nf3.parse(L�ngengrad.getText());
				L�ngen  = sd.doubleValue();
				
			}
			catch (ParseException ex) {
			
		}
			myAuto.setL�ngengrad(L�ngen);
			

			//true,wenn Dialog durch Ok beendet wird.
			closedOK = true;
		}
		// Dialog schlie�en:
		setVisible (false);
	}
}



